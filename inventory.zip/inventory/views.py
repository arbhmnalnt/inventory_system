from django.shortcuts import render, get_object_or_404, redirect
from .models import InventoryItem, InventoryTransaction
from django.contrib.auth.decorators import login_required
from django.urls import reverse

# Inventory Items CRUD

@login_required
def inventory_item_list(request):
    items = InventoryItem.objects.all()
    return render(request, 'inventory/inventory_item_list.html', {'items': items})

@login_required
def inventory_item_create(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        category = request.POST.get('category')
        quantity = request.POST.get('quantity')
        description = request.POST.get('description')
        InventoryItem.objects.create(
            name=name, 
            category=category, 
            quantity=quantity, 
            description=description
        )
        return redirect('inventory_item_list')
    return render(request, 'inventory/inventory_item_form.html')

@login_required
def inventory_item_update(request, pk):
    item = get_object_or_404(InventoryItem, pk=pk)
    if request.method == 'POST':
        item.name = request.POST.get('name')
        item.category = request.POST.get('category')
        item.quantity = request.POST.get('quantity')
        item.description = request.POST.get('description')
        item.save()
        return redirect('inventory_item_list')
    return render(request, 'inventory/inventory_item_form.html', {'item': item})

@login_required
def inventory_item_delete(request, pk):
    item = get_object_or_404(InventoryItem, pk=pk)
    if request.method == 'POST':
        item.delete()
        return redirect('inventory_item_list')
    return render(request, 'inventory/inventory_item_delete_confirm.html', {'item': item})

# Inventory Transactions CRUD

@login_required
def inventory_transaction_list(request):
    transactions = InventoryTransaction.objects.all()
    return render(request, 'inventory/inventory_transaction_list.html', {'transactions': transactions})

@login_required
def inventory_transaction_create(request):
    items = InventoryItem.objects.all()
    if request.method == 'POST':
        item_id = request.POST.get('inventory_item')
        transaction_type = request.POST.get('transaction_type')
        quantity = request.POST.get('quantity')
        item = get_object_or_404(InventoryItem, pk=item_id)
        InventoryTransaction.objects.create(
            inventory_item=item,
            transaction_type=transaction_type,
            quantity=quantity
        )
        # Optionally adjust inventory quantity here based on type.
        return redirect('inventory_transaction_list')
    return render(request, 'inventory/inventory_transaction_form.html', {'items': items})
